# CDK Pipelines Demo -- Python

This branch contains sample code in Python used for the
CDK Pipelines Webinar.

[Back to `main` branch](https://github.com/aws-samples/cdk-pipelines-demo)

## Webinar: Enhanced CI/CD with AWS CDK

[![Enhanced CI/CD with AWS CDK](http://img.youtube.com/vi/1ps0Wh19MHQ/0.jpg)](https://www.youtube.com/watch?v=1ps0Wh19MHQ)
