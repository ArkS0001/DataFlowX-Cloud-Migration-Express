def handler(event, context):
  return {
    'body': 'Oops',
    'statusCode': '500'
  }